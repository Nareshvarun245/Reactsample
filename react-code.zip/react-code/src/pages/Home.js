// Home.js
import React from 'react';

function Home() {
  return <div>This is the Home Page</div>;
}

export default Home;